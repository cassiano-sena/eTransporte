# eTransporte v1.1 Beta

>CS - Web Programming Project by Cassiano de Sena and Eduardo Miguel.
>
>(To get the latest version, make sure to install the '.zip' file!)
>
>The project is now in Beta Phase:
>Now the project is being updated on both the backend and the frontend (instead of just updating design).


26/06/2023 - 12:53 - Cassiano - v1.1


Front:
- More fidelity to the prototype;
- Updated CSS (in progress);

Back:
- Introducing CURL for API-cosuming work;
- JWT is now being used;
- The 'Login' files are being tested;
