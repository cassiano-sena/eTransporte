# eTransporte v1.2 Beta

>CS - Web Programming Project by Cassiano de Sena and Eduardo Miguel.
>
>(To get the latest version, make sure to install the '.zip' file!)
>
>The project is now in Beta Phase:
>Now the project is being updated on both the backend and the frontend (instead of just updating design).


26/06/2023 - 17:11 - Cassiano - v1.2


Front:
- More fidelity to the prototype;
- Updated CSS (in progress);

Back:
- Introducing CURL for API-cosuming work;
- JWT is now being used;
- The 'Login' files are being tested;
