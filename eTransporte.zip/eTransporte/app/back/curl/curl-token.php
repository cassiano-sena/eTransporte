<?php
// session_start();
// require_once "dbconnect.php";


$email = $_POST['email'];
$senha = $_POST['senha'];
if ($email != "" && $senha != "") {

  $curl = curl_init();

  curl_setopt_array($curl, [
    CURLOPT_URL => "http://127.0.0.1/eTransporte/app/back/",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => "{\n  \"name\": \"generateToken\",\n  \"param\": {\n    \"email\": \"$email\",\n    \"senha\": \"$senha\"\n  }\n}",
    CURLOPT_HTTPHEADER => [
      "Accept: */*",
      "Content-Type: application/json",
      "User-Agent: Thunder Client (https://www.thunderclient.com)"
    ],
  ]);

  $response = curl_exec($curl);
  $err = curl_error($curl);

  curl_close($curl);

  if ($err) {
    echo "cURL Error #:" . $err;
  } else {
    $responseData = json_decode($response, true);
    if ($responseData && isset($responseData['response']['status'])) {
      $httpStatusCode = $responseData['response']['status'];
      $expectedStatusCode = 200;

      if ($httpStatusCode === $expectedStatusCode) {
        // session_start();
        $_SESSION['token'] = $responseData['response']['result']['token'];

        // $conexao = new PDO('mysql:host=localhost;dbname=projeto_pw', 'root', '');
        $conexao = new PDO('mysql:host=localhost;dbname=projeto_pw', 'root', 'root');
        $stmt = $conexao->prepare("SELECT * FROM tab_usuarios WHERE email=:email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($usuario) {
          $usuario_id = $usuario['usuario_id'];
          $usuario_nome = $usuario['nome'];
          $_SESSION['usuario_id'] = $usuario_id;
          $_SESSION['nome'] = $usuario_nome;
          // $_SESSION['email'] = $email;
          // $_SESSION['telefone'] = $telefone;
          // $_SESSION['senha'] = $senha;
          // $_SESSION['is_admin'] = $is_admin;
          // $_SESSION['is_admin'] = $is_admin;
          // $_SESSION['is_driver'] = $is_driver;
          // $_SESSION['is_active'] = $is_active;
          // $_SESSION['usuario_status'] = $usuario_status;
          // $_SESSION['created_one'] = $created_one;

          header("Location: http://localhost/eTransporte/app/front/paginas/home.php");
          exit();
        } else {
          echo "User not found.";
        }
      } else {
        echo "Invalid response: " . $httpStatusCode;
      }
    } else {
      echo "Invalid response format.";
    }
  }
}