<?php
$token=$_POST['token'];
$usuario_id=$_POST['usuario_id'];
$nome=$_POST['nome'];
$email=$_POST['email'];
$senha=$_POST['senha'];
$telefone=$_POST['telefone'];
$is_admin=$_POST['is_admin'];
$is_driver=$_POST['is_driver'];
$cidade=$_POST['cidade'];
$rotas=$_POST['rotas'];
$imagem=$_POST['imagem'];

$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => "http://127.0.0.1/eTransporte/app/back/",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "{\n  \"name\": \"updateUsuario\",\n  \"param\": {\n    \"usuario_id\": \"$usuario_id\",\n    \"nome\": \"$nome\",\n    \"email\": \"$email\",\n    \"telefone\": \"$telefone\",\n    \"senha\": \"$senha\",\n    \"is_admin\": \"$is_admin\",\n    \"is_driver\": \"$is_driver\",\n    \"cidade\": \"$cidade\",\n    \"rotas\": \"$rotas\",\n    \"imagem\": \"$imagem\"\n  }\n}",
  CURLOPT_HTTPHEADER => [
    "Accept: */*",
    "Authorization: Bearer $token",
    "Content-Type: application/json",
    "User-Agent: Thunder Client (https://www.thunderclient.com)"
  ],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}