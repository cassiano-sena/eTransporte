<?php
function ReceberParametro($campo, $default='')
{
    if (isset($_REQUEST[$campo]))
        $aux = LimparParametro2($_REQUEST[$campo]);
    else
        $aux = $default;
    return $aux;
}

function ReceberValor($campo, $alterar='S')
{
    if (isset($_REQUEST[$campo])) {
        $aux = $_REQUEST[$campo];
        if( $alterar == 'S' ) $aux = str_replace(",",".",str_replace(".","",$aux));
    }
    else
        $aux = '0.00';
    return $aux;
}

function ReceberURL( $campo ){
    if (isset($_REQUEST[$campo]))
        $aux = LimparParametro($_REQUEST[$campo]);
    else
        $aux = '';
    return $aux;
}

function LimparValor( $aux ){
    $aux = str_replace(",",".",str_replace(".","",$aux));
    return $aux;
}

function LimparParametro($string)
{
    if (get_magic_quotes_gpc()) {
        $string = stripslashes($string);
    }

    $string = escape($string);
    $badWords = array("/iframe/i", "/delete/i", "/update/i", "/script/i", "/onmouseover/i", "/union/i", "/insert/i", "/drop/i", "/--/i");
    $string = preg_replace($badWords, "", $string);
    return $string;
}

function LimparParametro2($str){
    // Remove palavras suspeitas de injection.
    $badString = "/(\n|\r|%0a|%0d|Content-Type:|bcc:|to:|cc:|Autoreply:|#|";
    $badString .= "from|select|insert|delete|where|drop table|show tables|";
    $badString .= "FROM|SELECT|INSERT|DELETE|WHERE|DROP TABLE|SHOW TABLES|";
    $badString .= "iframe|script|onmouseover|union|http|drop|onclick|onchange|";
    $badString .= "IFRAME|SCRIPT|ONMOUSEOVER|UNION|HTTP|DROP|ONCLICK|ONCHANGE|";
    $badString .= " or | and |1=1|true|false|";
    $badString .= "\*|--|\\\\)/";
    $str = preg_replace($badString, '', $str);
    $str = trim($str);        // Remove espaços vazios.
    $str = strip_tags($str);  // Remove tags HTML e PHP.
    $str = addslashes($str);  // Adiciona barras invertidas à uma string.
    return $str;
}