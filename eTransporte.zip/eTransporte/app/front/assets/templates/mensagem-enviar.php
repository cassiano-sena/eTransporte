<?php
// error_reporting(E_ALL);
// ini_set('display_errors', 1);
require_once '../security/path.php';
$conexao = new PDO('mysql:host=localhost;dbname=projeto_pw', 'root', '');
// $conexao = new PDO('mysql:host=localhost;dbname=projeto_pw', 'root', 'root');
$stmt = $conexao->prepare("SELECT * FROM tab_rotas");
$stmt->execute();
$rotas = $stmt->fetchAll(PDO::FETCH_ASSOC);

$usuario_id=$_SESSION['usuario_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $descricao = $_POST['descricao'];
    $rota = $_POST['rota'];

    $servername = "localhost";
    $username = "root";
    $password = "root";
    // $password = "";
    $dbname = "projeto_pw";

    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    $stmt = $pdo->prepare("INSERT INTO tab_mensagens (usuario, descricao, rota) VALUES (:usuario, :descricao, :rota)");
    $stmt->bindParam(':usuario', $usuario_id);
    $stmt->bindParam(':descricao', $descricao);
    $stmt->bindParam(':rota', $rota);
    $stmt->execute();

    header("Location: ".PAGES."mensagem.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap-grid.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>index.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>comum.css">
    <script src="<?php echo JS ;?>bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>eTransporte</title>
    <style>
        .mensagem-enviar-box{
            overflow:hidden;
        }
    </style>
    <script>
        $(document).ready(function() {
            //REMOVER
            $('#enviar').click(function() {
                e.preventDefault();
                var mensagemId = $(this).closest('.mensagem-historico-box').find('.mensagem-id').val();
                var token = '<?php echo addslashes(json_encode($_SESSION['token'])); ?>';
                var rota_id = $('#rota').val();
                var descricao = $('#descricao').val();
                var usuario_id= '<?php echo addslashes(json_encode($_SESSION['usuario_id'])); ?>';

                $.ajax({
                url: '../../back/curl/curl-addmessage.php',
                method: 'POST',
                data: {
                    usuario_id: usuario_id,
                    rota_id: rota_id,
                    descricao: descricao,
                    token: token
                },
                success: function(response) {
                    console.log(response);
                    location.reload();
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
                });
            });
        });
    </script>
</head>
<body>
<div class="conteudo">
    <div class="mensagem-enviar-box">
        <div class="mensagem-enviar-transporte">
            <div class="msg-enviar-transporte"  style="height:100%; width:100%;">
                <div>
                <?php echo $_SESSION['nome']; ?>
                </div><br>
                <img src="<?php echo IMAGES ;?>usuario.png" alt="usuário" width="50px" style="padding:10px; padding-left:4px;">
            </div>
        </div>
        <div class="mensagem-enviar-content">
            <form method="POST" action="">
                <div style="margin-top:10px;">
                    <textarea id="descricao" name="descricao" rows="4" cols="50" class="mensagem-enviar-field" placeholder="Descrição" required><?php echo isset($descricao) ? $descricao : ''; ?></textarea>
                </div>
                <div style="text-align:left;line-height:1.5;height:50px;">
                    <div class="select-rota" style="display:flex;margin:10px;margin-right:20px;">
                        <select id="rota" name="rota" id="" required>
                            <?php foreach ($rotas as $rota): ?>
                            <option id="" value="<?php echo $rota['rota_id']; ?>"><?php echo $rota['rota']; ?></option>    
                            <?php endforeach; ?>
                        </select>
                        <div class="spacer"></div>
                        <button type="submit" id="enviar" class="btn btn-primary btn-sm">Enviar</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
