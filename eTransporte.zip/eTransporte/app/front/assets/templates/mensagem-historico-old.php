<?php
// error_reporting(E_ALL);
// ini_set('display_errors', 1);
require_once '../security/path.php';

// $conexao = new PDO('mysql:host=localhost;dbname=projeto_pw', 'root', '');
$conexao = new PDO('mysql:host=localhost;dbname=projeto_pw', 'root', 'root');
$stmt = $conexao->prepare("SELECT * FROM tab_mensagens ORDER BY hora ");
// $stmt->bindParam(':rota', $rota);
$stmt->execute();
$mensagem = $stmt->fetch(PDO::FETCH_ASSOC);

if ($mensagem) {
  $usuario = $mensagem['usuario'];
  $descricao = $mensagem['descricao'];
//   $_SESSION['usuario_id'] = $usuario_id;
//   $_SESSION['nome'] = $usuario_nome;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap-grid.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>index.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>comum.css">
    <script src="<?php echo JS ;?>bootstrap.min.js"></script>
    <title>eTransporte</title>
    <style>
        .mensagem-util{
            display:inline-block;
            text-align:right;
        }
        .mensagem-historico-box{
            overflow:hidden;
        }
        .msg-historico-content{
            flex:1;
            width:100%;
        }
    </style>
</head>
<body>
    <div class="conteudo">
        <div class="title-left">
            Histórico
        </div>
        <span class="mensagem-historico-box">
            <div class="mensagem-historico-field">
                <div class="msg-historico-user" style="height:100%; width:30%; padding-left:4px;">Usuário 1<br>
                    <img src="<?php echo IMAGES ;?>usuario.png" alt="usuario" width="50px" style="padding:10px; padding-left:4px;">
                </div>
                <div class="msg-historico-content" style="">Mensagem 1<br>
                </div>
                <div class="mensagem-util">
                    <button type="button" class="btn btn-secondary btn-sm">Editar</button>
                    <button type="button" class="btn btn-danger btn-sm">Remover</button>
                </div>
            </div>
        </span>
        <span class="mensagem-historico-box">
            <div class="mensagem-historico-field">
                <div class="msg-historico-user" style="height:100%; width:30%; padding-left:4px;">Usuário 2<br>
                    <img src="<?php echo IMAGES ;?>usuario.png" alt="usuario" width="50px" style="padding:10px; padding-left:4px;">
                </div>
                <div class="msg-historico-content" style="">Mensagem 2<br>
                </div>
                <div class="mensagem-util">
                    <button type="button" class="btn btn-secondary btn-sm">Editar</button>
                    <button type="button" class="btn btn-danger btn-sm">Remover</button>
                </div>
            </div>
        </span>   
        <span class="mensagem-historico-box">
            <div class="mensagem-historico-field">
                <div class="msg-historico-user" style="height:100%; width:30%; padding-left:4px;">Usuário 3<br>
                    <img src="<?php echo IMAGES ;?>usuario.png" alt="usuario" width="50px" style="padding:10px; padding-left:4px;">
                </div>
                <div class="msg-historico-content" style="">Mensagem 3<br>
                </div>
                <div class="mensagem-util">
                    <button type="button" class="btn btn-secondary btn-sm">Editar</button>
                    <button type="button" class="btn btn-danger btn-sm">Remover</button>
                </div>
            </div>
        </span>   
    </div>
</body>
</html>