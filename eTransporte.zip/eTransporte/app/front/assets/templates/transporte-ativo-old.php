<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once '../security/path.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap-grid.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>index.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>comum.css">
    <script src="<?php echo JS ;?>bootstrap.min.js"></script>
    <title>eTransporte</title>
    <style>
        .enclosed-box{
            overflow:hidden;
        }
        .transport-item{
            width:80px;
            margin:5px;
            font-size:14px;
            line-height:2.5;
            text-align:center;
        }
        .item-title{
            font-size:8px;
            overflow:hidden;
        }
    </style>
</head>
<body>
    <div class="conteudo">
        <span class="transportes-disponiveis">
            <div id="participado" class="participado">
                <div class="title-left">Meus Transportes</div>
                <div class="enclosed-box" style="display:flex;">
                    <div class="transport-item" style="">
                        <img src="<?php echo IMAGES ;?>bus.png" alt="transporte" width="40px" style="margin-top:10px;"><br>
                        <o class="item-title">Transporte 1</o><br>
                        <button type="button" class="btn btn-primary btn-sm" onclick="action('Transport-See')">Ver</button>
                    </div>
                    <div class="transport-item" style="">
                        <img src="<?php echo IMAGES ;?>bus.png" alt="transporte" width="40px" style="margin-top:10px;"><br>
                        <o class="item-title">Transporte 1</o><br>
                        <button type="button" class="btn btn-primary btn-sm" onclick="action('Transport-See')">Ver</button>
                    </div>
                    <div class="transport-item" style="">
                        <img src="<?php echo IMAGES ;?>bus.png" alt="transporte" width="40px" style="margin-top:10px;"><br>
                        <o class="item-title">Transporte 1</o><br>
                        <button type="button" class="btn btn-primary btn-sm" onclick="action('Transport-See')">Ver</button>
                    </div>
                </div>
            </div>
        </span>
    </div>
</body>
</html>