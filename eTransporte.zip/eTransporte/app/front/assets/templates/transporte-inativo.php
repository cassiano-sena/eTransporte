<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once '../security/path.php';

$conexao = new PDO('mysql:host=localhost;dbname=projeto_pw', 'root', 'root');
$stmt = $conexao->prepare("SELECT * FROM tab_rotas");
$stmt->execute();
$rotas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap-grid.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>index.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>comum.css">
    <script src="<?php echo JS ;?>bootstrap.min.js"></script>
    <title>eTransporte</title>
    <style>
        .enclosed-box{
            overflow:hidden;
        }
        .transport-item{
            width:80px;
            margin:5px;
            font-size:14px;
            line-height:2.5;
            text-align:center;
        }
        .item-title{
            font-size:8px;
            overflow:hidden;
        }
    </style>
</head>
<body>
    <div class="conteudo">
        <div class="title-left">Transportes Disponíveis</div>
        <div class="enclosed-box" style="display:flex;">
            <?php foreach ($rotas as $rota): ?>
            <div class="transport-item">
                <img src="<?php echo $rota['imagem']; ?>" alt="<?php echo $rota['rota']; ?>" width="40px" style="font-size:10px;margin-top:10px;"><br>
                <o class="item-title"><?php echo $rota['rota']; ?></o><br>
                <button type="button" class="btn btn-primary btn-sm" onclick="action('Transport-See')">Ver</button>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
