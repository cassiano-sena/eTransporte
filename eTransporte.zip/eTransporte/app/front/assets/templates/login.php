<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once '../security/path.php';
require_once CURL.'curl-token.php';
// require_once BACKEND.'dbconnect.php';
// require_once BACKEND.'api.php';

$email="";
$senha="";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap-grid.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>index.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>comum.css">
    <script src="<?php echo JS ;?>bootstrap.min.js"></script>
    <title>eTransporte</title>
    <script language="javascript">
        function login(){
            let user=document.getElementById("usuario");
            let pass=document.getElementById("senha");
            generateToken(user,pass);

        }
    </script>
</head>
<body>
    <div class="conteudo">
        <div class="home-title">
            <div class="login-main">
            <img class="etransporte-header-icon" src="<?php echo IMAGES ;?>etransporte.png" alt="menu" width="100px" style="position:center;margin:0;margin-top:100px; margin-bottom:50px;">
                <div class="login-1">
                    <input id="usuario" class="input-login" type="text" placeholder="Usuário" style="width:240px;" value="<?php $email; ?>">
                    <input id="senha" class="input-login" type="password" placeholder="Senha" style="width:240px;" value="<?php $senha; ?>">
                    <div class="login-center">Esqueceu a senha? <a href="<?php echo PAGES; ?>recuperar_senha.php" class="redefinir">Redefinir</a></div>
                </div>
                <div class="buttons">
                    <div class="register">
                        <button class="btn btn-primary"  type="button" value="Register" style="" onclick="action(this.value)">Nova Conta</button>
                    </div>
                    <div class="login">
                        <button class="btn btn-primary" type="button" value="Login" style="margin-left:45px;" onclick="login($email,$senha)">Log in</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>