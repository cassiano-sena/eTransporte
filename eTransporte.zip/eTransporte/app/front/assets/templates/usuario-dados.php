<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once '../security/path.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap-grid.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>index.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>comum.css">
    <script src="<?php echo JS ;?>bootstrap.min.js"></script>
    <title>eTransporte</title>
</head>
<body>
    <div class="conteudo">
        <div class="home-title">
            <span class="usuario-dados">
                <div class="foto">
                    <img src="<?php echo IMAGES; ?>usuario.png" width="150px" alt="" class="usuario"><br>
                    <div id="nome-usuario"class="nome-usuario">
                        Usuário
                    </div>
                    <div class="spacer"></div>
                    <button type="button" class="btn btn-danger btn-sm">Remover</button>
                    <!-- <div id="nome" class="nome">< ?php echo $nome;?></div> -->
                </div>
                <div class="informacoes">
                    <div class="style-group-together">
                        <div id="nome" class="nome">
                            <!-- <div>
                                Nome
                            </div>     -->
                            <div>
                                <input type="text" id="input-nome" value="<?php $nome ?>" placeholder="Nome">
                            </div>    
                            
                        </div>
                        <div id="email" class="email">
                            <!-- <div>
                                Email
                            </div>     -->
                            <div>
                                <input type="text" id="input-email" value="<?php $email ?>" placeholder="Email">
                            </div>
                            
                        </div>
                        <div id="senha" class="senha">
                            <!-- <div>
                                Senha
                            </div>     -->
                            <div>
                                <input type="text" id="input-senha" value="<?php $senha ?>" placeholder="Senha">
                            </div>
                            
                        </div>
                        <div id="telefone" class="telefone">
                            <!-- <div>
                                Telefone
                            </div>     -->
                            <div>
                                <input type="text" id="input-telefone" value="<?php $telefone ?>" placeholder="Telefone">
                            </div>
                            
                        </div>
                        <div id="cidade" class="cidade">
                            <!-- <div>
                                Cidade
                            </div>     -->
                            <div>
                                <input type="text" id="input-cidade" placeholder="Cidade">
                            </div>
                            
                        </div>
                        <div id="endereco" class="endereco">
                            <!-- <div>
                                Endereço
                            </div>     -->
                            <div>
                                <input type="text" id="input-endereco" placeholder="Endereço">
                            </div>
                            
                        </div>
                        <div id="universidade" class="universidade">
                            <!-- <div>
                                Universidade
                            </div>     -->
                            <div>
                                <input type="text" id="input-universidade" placeholder="Universidade">
                            </div>
                            
                        </div>
                        <div id="matricula" class="matricula">
                            <!-- <div>
                                Matrícula
                            </div>     -->
                            <div>
                                <input type="text" id="input-matricula" placeholder="Matrícula">
                            </div>                            
                            
                        </div>
                        <div id="motorista" class="motorista">
                            <!-- <div>
                                Motorista
                            </div>     -->
                            <div>
                                Motorista:
                                <select name="motorista" id="">
                                    <option value="<?php $is_driver ?>">Motorista</option>
                                    <option value="0">Não</option>
                                    <option value="1">Sim</option>
                                </select>
                            </div>
                            
                            
                        </div>
                        <div id="cnh" class="cnh">
                            <!-- <div>
                                CNH
                            </div>     -->
                            <div>
                                <input type="text" id="input-cnh" placeholder="CNH">
                            </div>
                            
                        </div>
                        <div id="transporte" class="transporte">
                            <!-- <div>
                                Transporte
                            </div>     -->
                            <div>
                                <input type="text" id="input-transporte" placeholder="Transporte">
                            </div>
                            
                        </div>
                        <div id="administrador" class="administrador">
                            <!-- <div>
                                Administrador
                            </div>     -->
                            <div>
                                Administrador:
                                <select name="administrador" id="">
                                    <option value="<?php $is_admin ?>">Administrador</option>
                                    <option value="0">Não</option>
                                    <option value="1">Sim</option>
                                </select>
                            </div>
                            
                        </div>
                        <button type="button" class="btn btn-primary btn-sm">Editar</button>
                        <button type="button" class="btn btn-secondary btn-sm">Salvar</button>
                    </div>
                </div>
            </span>
        </div>
    </div>
</body>
</html>