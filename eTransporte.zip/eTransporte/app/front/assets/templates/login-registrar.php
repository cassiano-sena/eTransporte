<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once '../security/path.php';
// require_once BACKEND.'dbconnect.php';
// require_once BACKEND.'usuario.php';
require_once BACKEND.'rest.php';
require_once BACKEND.'api.php';
require_once BACKEND.'dbconnect.php';
require_once SECURITY.'funcoes.php';


// Check if the user ID exists in the session
if(isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    // Use the user ID as needed
    echo "User ID: " . $userId;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap-grid.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>index.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>comum.css">
    <script src="<?php echo JS ;?>bootstrap.min.js"></script>
    <title>eTransporte</title>
    <script>
        function adicionarUsuario(){
            let nome=document.getElementById("nome");
            let email=document.getElementById("email");
            let senha=document.getElementById("password");
            if(Usuario.insert(nome,email,senha)){
                window.location.href='<?php echo PAGES ;?>login.php';
            }else alert("Não deu!");
        }
        // function togglePassword(){
        // }
    </script>
</head>
<body>
    <div class="conteudo">
        <div class="home-title">
            <div class="login-main">
            <img class="etransporte-header-icon" src="<?php echo IMAGES ;?>etransporte.png" alt="menu" width="100px" style="position:center;margin:0;margin-top:100px; margin-bottom:50px;">
                <div class=login-1>
                    <input class="input-login" id="nome" type="text" placeholder="Nome">
                    <!-- <input class="input-login" id="sobrenome" type="text" placeholder="Sobrenome"> -->
                    <input class="input-login" id="email" type="email" placeholder="Email">
                    <input class="input-login" id="password" type="password" placeholder="Senha"><img class="icon" src="<?php echo IMAGES ;?>eye.png" alt="menu" width="20px" style="position:absolute;margin-top:20px;"></input>
                </div>
                <div class="buttons" style="justify-content:center;">
                    <div>
                        <!-- <button type="button" class="btn btn-primary" value="Create" style="" onclick="action(this.value)">Criar Conta</button> -->
                        <button type="button" class="btn btn-primary" value="Create" style="" onclick="adicionarUsuario()">Criar Conta</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>