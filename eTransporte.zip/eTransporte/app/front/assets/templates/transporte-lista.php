<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once '../security/path.php';

// $conexao = new PDO('mysql:host=localhost;dbname=projeto_pw', 'root', '');
$conexao = new PDO('mysql:host=localhost;dbname=projeto_pw', 'root', 'root');
$stmt = $conexao->prepare("SELECT * FROM tab_rotas");
$stmt->execute();
$rotas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap-grid.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>index.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>comum.css">
    <script src="<?php echo JS ;?>bootstrap.min.js"></script>
    <title>eTransporte</title>
    <style>
        .enclosed-box{
            overflow:hidden;
        }
        .transport-item{
            width:80px;
            margin:5px;
            font-size:14px;
            line-height:2.5;
            text-align:center;
        }
        .item-title{
            font-size:8px;
            overflow:hidden;
        }
        #input-stylized{
            font-size:10px;
            width:80px;
            height: 30px;
            border-radius: 10px;
            background-color: #A2A6A8;
        }
    </style>
</head>
<body>
    <div class="conteudo">
        <div class="title-left">Transportes Disponíveis</div>
        <?php foreach ($rotas as $rota): ?>
        <div class="enclosed-box" style="display:flex;">
            <div class="transport-item">
                <img src="<?php echo IMAGES ;?>bus.png" alt="<?php echo $rota['rota']; ?>" width="40px" style="font-size:10px;margin-top:10px;"><br>
                <input id="input-stylized" type="text" style="font-size:10px;" value="<?php echo $rota['rota']; ?>" placeholder="Título"></input>
            </div>
            <div class="notificacao-mensagem">
                <div class="not-mesg-user" style="height:100%; width:30%;">Motorista<br>
                <h5 style="font-size:10px;">
                <input id="input-stylized" type="text" value="<?php echo $rota['motorista']; ?>" placeholder="Nome"></input>
                <br>
                <!-- <input id="input-stylized" type="text" value="< ?php echo $rota['telefone']; ?>" placeholder="Telefone"></input> -->
                </h5>
                </div>
                
                <div>
                Horários
                <div class="rota-cad" style="font-size:14px; line-height: 0.8;display:flex;justify-content:center;">
                        <div class="rotas">
                            <div class="rotas-dados">
                                <div class="rotas-percurso-3">
                                    <input id="input-stylized" type="text" value="<?php echo $rota['datas']; ?>" placeholder="Datas"></input>
                                    <input id="input-stylized" type="text" value="<?php echo $rota['horarios']; ?>" placeholder="Embarque e Desembarque"></input>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="not-mesg-content" style="height:100%; width:100%; margin-bottom:50px;"><br>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14230.406809397276!2d-48.664329!3d-26.916133000000002!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94d8cb8842138761%3A0x648dbc8d0ef634c1!2sUniversidade%20do%20Vale%20do%20Itaja%C3%AD%2C%20Campus%20Itaja%C3%AD!5e0!3m2!1spt-BR!2sbr!4v1688152142333!5m2!1spt-BR!2sbr" width="350" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
                    
                <div style="justify-content:center; line-height:2;">
                    <button type="button" class="btn btn-danger btn-sm">Remover</button>
                    <button type="button" class="btn btn-success btn-sm hidden">Salvar</button>
                    <button type="button" class="btn btn-primary btn-sm edit-btn">Editar</button>
                    <button type="button" class="btn btn-secondary btn-sm hidden">Cancelar</button>
                </div>
                
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
<script>
    const editButtons = document.querySelectorAll(".edit-btn");
    const salvarButtons = document.querySelectorAll(".btn-success");
    const cancelarButtons = document.querySelectorAll(".btn-secondary");
    const readOnlySections = document.querySelectorAll(".read-only");

    // Function to toggle the visibility and read-only status of elements
    function toggleEditMode() {
        readOnlySections.forEach((section) => {
            section.readOnly = !section.readOnly;
        });
        salvarButtons.forEach((button) => {
            button.classList.toggle("hidden");
        });
        cancelarButtons.forEach((button) => {
            button.classList.toggle("hidden");
        });
    }

    // Add click event listeners to "Editar" buttons
    editButtons.forEach((button) => {
        button.addEventListener("click", toggleEditMode);
    });

    // Add click event listeners to "Salvar" and "Cancelar" buttons
    salvarButtons.forEach((button) => {
        button.addEventListener("click", toggleEditMode);
    });

    cancelarButtons.forEach((button) => {
        button.addEventListener("click", toggleEditMode);
    });
</script>
</html>
