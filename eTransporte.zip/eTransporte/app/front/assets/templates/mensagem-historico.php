<?php
// session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once '../security/path.php';
// require_once  BACKEND . 'api.php';
require_once CURL.'curl-getmessage.php';
require_once CURL.'curl-updatemessage.php';
require_once BACKEND.'dbconnect.php';
require_once SECURITY.'funcoes.php';


// Check if the user ID exists in the session
if(isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    // Use the user ID as needed
    echo "User ID: " . $userId;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap-grid.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>index.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>comum.css">
    <script src="<?php echo JS ;?>bootstrap.min.js"></script>
    <title>eTransporte</title>
    <style>
        .mensagem-util{
            display:inline-block;
        }
    </style>
</head>
<body>
    <div class="conteudo">
        <div class="title-left">
            Histórico
        </div>
        <span class="mensagem-historico-box">
            <div class="mensagem-historico-field">
                <div class="msg-historico-user" style="height:100%; width:30%; padding-left:4px;">Usuário<br>
                    <img src="<?php echo IMAGES ;?>usuario.png" alt="usuario" width="50px" style="padding:10px; padding-left:4px;">
                </div>
                <div class="msg-historico-content" style="height:100%; width:70%;">Mensagem<br>
                    <img src="<?php echo IMAGES ;?>e-mail.png" alt="" width="50px" style="padding:10px; padding-left:4px;">
                </div>
                <div class="mensagem-util">
                    <button type="button" class="btn btn-secondary btn-sm">Editar</button>
                    <button type="button" class="btn btn-danger btn-sm">Remover</button>
                </div>
            </div>
        </span>
        <span class="mensagem-historico-box">
            <div class="mensagem-historico-field">
                <div class="msg-historico-user" style="height:100%; width:30%; padding-left:4px;">Usuário<br>
                    <img src="<?php echo IMAGES ;?>usuario.png" alt="usuario" width="50px" style="padding:10px; padding-left:4px;">
                </div>
                <div class="msg-historico-content" style="height:100%; width:70%;">Mensagem<br>
                    <img src="<?php echo IMAGES ;?>e-mail.png" alt="" width="50px" style="padding:10px; padding-left:4px;">
                </div>
                <div class="mensagem-util">
                    <button type="button" class="btn btn-secondary btn-sm">Editar</button>
                    <button type="button" class="btn btn-danger btn-sm">Remover</button>
                </div>
            </div>
        </span>   
        <span class="mensagem-historico-box">
            <div class="mensagem-historico-field">
                <div class="msg-historico-user" style="height:100%; width:30%; padding-left:4px;">Usuário<br>
                    <img src="<?php echo IMAGES ;?>usuario.png" alt="usuario" width="50px" style="padding:10px; padding-left:4px;">
                </div>
                <div class="msg-historico-content" style="height:100%; width:70%;">Mensagem<br>
                    <img src="<?php echo IMAGES ;?>e-mail.png" alt="" width="50px" style="padding:10px; padding-left:4px;">
                </div>
                <div class="mensagem-util">
                    <button type="button" class="btn btn-secondary btn-sm">Editar</button>
                    <button type="button" class="btn btn-danger btn-sm">Remover</button>
                </div>
            </div>
        </span>   
    </div>
</body>
</html>