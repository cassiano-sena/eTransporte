<?php
require_once '../security/path.php';
$conexao = new PDO('mysql:host=localhost;dbname=projeto_pw', 'root', 'root');
$stmt = $conexao->prepare("SELECT * FROM tab_mensagens ORDER BY hora ");
$stmt->execute();
$mensagens = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap-grid.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>index.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>comum.css">
    <script src="<?php echo JS ;?>bootstrap.min.js"></script>
    <title>eTransporte</title>
    <style>
        .mensagem-util{
            display:inline-block;
            text-align:right;
        }
        .mensagem-historico-box{
            overflow:hidden;
        }
        .msg-historico-content{
            flex:1;
            width:100%;
        }
    </style>
</head>
<body>
<div class="conteudo">
        <div class="title-left">
            Histórico
        </div>
        
        <?php foreach ($mensagens as $mensagem): ?>
        <?php
            $usuarioId = $mensagem['usuario'];
            $rotaId = $mensagem['rota'];
            $hora = $mensagem['hora'];

            // Retrieve usuario and rota from their respective tables
            $usuarioStmt = $conexao->prepare("SELECT * FROM tab_usuarios WHERE usuario_id = :usuarioId");
            $usuarioStmt->bindParam(':usuarioId', $usuarioId);
            $usuarioStmt->execute();
            $usuario = $usuarioStmt->fetch(PDO::FETCH_ASSOC);

            $rotaStmt = $conexao->prepare("SELECT * FROM tab_rotas WHERE rota_id = :rotaId");
            $rotaStmt->bindParam(':rotaId', $rotaId);
            $rotaStmt->execute();
            $rota = $rotaStmt->fetch(PDO::FETCH_ASSOC);
        ?>
        <span class="mensagem-historico-box">
            <div class="mensagem-historico-field">
                <div class="msg-historico-user" style="height:100%; width:30%; padding-left:4px;padding-top:4px; font-size:10px; line-height:1.5;">
                    <?php echo $usuario['nome']; ?>
                    <?php echo " - "; ?>
                    <?php echo $rota['rota']; ?>
                    <?php echo " ["; ?>
                    <?php echo $mensagem['hora']; ?>
                    <?php echo "] "; ?><br>
                    <img src="<?php echo IMAGES ;?>usuario.png" alt="usuario" width="50px" style="padding:10px; padding-left:4px;">
                </div>
                <div class="msg-historico-content" style="padding-left:5px;padding-right:5px;text-align:justify;font-size:12px;">
                    <?php echo $mensagem['descricao']; ?><br>
                </div>
                <div class="mensagem-util">
                    <button type="button" class="btn btn-secondary btn-sm">Editar</button>
                    <button type="button" class="btn btn-danger btn-sm">Remover</button>
                </div>
            </div>
        </span>
        <?php endforeach; ?>
        
    </div>
</body>
</html>