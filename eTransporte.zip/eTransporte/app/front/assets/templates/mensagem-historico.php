<?php
// session_start();

require_once '../security/path.php';
$conexao = new PDO('mysql:host=localhost;dbname=projeto_pw', 'root', 'root');
$stmt = $conexao->prepare("SELECT * FROM tab_mensagens ORDER BY hora ");
$stmt->execute();
$mensagens = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap-grid.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>index.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>comum.css">
    <script src="<?php echo JS ;?>bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>eTransporte</title>
    <style>
        .mensagem-util{
            display:inline-block;
            text-align:right;
        }
        .mensagem-historico-box{
            overflow:hidden;
        }
        .msg-historico-content{
            flex:1;
            width:100%;
        }
    </style>
</head>
<body>
<div class="conteudo">
        <div class="title-left">
            Histórico
        </div>
        
        <?php foreach ($mensagens as $mensagem): ?>
        <?php
            $usuarioId = $mensagem['usuario'];
            $rotaId = $mensagem['rota'];
            $hora = $mensagem['hora'];
            $mensagemId = $mensagem['mensagem_id'];
            $mensagemDataAttr = 'data-mensagem-id="' . $mensagemId . '"';
            // Retrieve usuario and rota from their respective tables
            $usuarioStmt = $conexao->prepare("SELECT * FROM tab_usuarios WHERE usuario_id = :usuarioId");
            $usuarioStmt->bindParam(':usuarioId', $usuarioId);
            $usuarioStmt->execute();
            $usuario = $usuarioStmt->fetch(PDO::FETCH_ASSOC);

            $rotaStmt = $conexao->prepare("SELECT * FROM tab_rotas WHERE rota_id = :rotaId");
            $rotaStmt->bindParam(':rotaId', $rotaId);
            $rotaStmt->execute();
            $rota = $rotaStmt->fetch(PDO::FETCH_ASSOC);
        ?>
        <span class="mensagem-historico-box" <?php echo $mensagemDataAttr; ?>>
            <div class="mensagem-historico-field">
                <div class="msg-historico-user" style="height:100%; width:30%; padding-left:4px;padding-top:4px; font-size:10px; line-height:1.5;">
                    <?php echo $usuario['nome']; ?><br>
                    <div style="font-size:8px;">
                        <?php echo $rota['rota']; ?>
                        <?php echo " ["; ?>
                        <?php echo $mensagem['hora']; ?>
                        <?php echo "] "; ?><br>
                    </div>
                    <img src="<?php echo IMAGES ;?>usuario.png" alt="usuario" width="50px" style="padding:10px; padding-left:4px;">
                </div>
                <div class="msg-historico-content" style="padding-left:5px;padding-right:5px;text-align:justify;font-size:12px;">
                    <?php echo $mensagem['descricao']; ?><br>
                </div>
                <div class="mensagem-util">
                    <button type="button" class="editar-btn btn btn-secondary btn-sm">Editar</button>
                    <button type="button" class="remover btn btn-danger btn-sm">Remover</button>
                </div>
            </div>
        </span>
        <?php endforeach; ?>
        
    </div>
    <script>
    $(document).ready(function() {
      // Editar button click event
      $('.editar-btn').click(function() {
        var box = $(this).closest('.mensagem-historico-box');

        // Check if already in edit mode
        if (!box.hasClass('edit-mode')) {
          // Enter edit mode
          box.addClass('edit-mode');

          var content = box.find('.msg-historico-content');
          var descricao = content.text().trim();

          // Create the input field
          var inputField = $('<input>')
            .attr('type', 'text')
            .addClass('message-enviar-field')
            .val(descricao);

          // Replace the content with the input field
          content.html(inputField);

          // Change the "Editar" button to "Salvar"
          $(this).text('Salvar');

          // Create the "Cancelar" button
          var cancelBtn = $('<button>')
            .attr('type', 'button')
            .addClass('cancelar-btn btn btn-danger btn-sm')
            .text('Cancelar');

          // Append the "Cancelar" button after the "Salvar" button
          $(this).after(cancelBtn);
        }
      });

      // Cancelar button click event
      $(document).on('click', '.cancelar-btn', function() {
        var box = $(this).closest('.mensagem-historico-box');

        // Remove the edit mode class
        box.removeClass('edit-mode');

        // Retrieve the original content
        var descricao = box.find('.message-enviar-field').val();

        // Replace the input field with the original content
        var content = box.find('.msg-historico-content');
        content.text(descricao);

        // Remove the input field and cancel button
        box.find('.message-enviar-field, .cancelar-btn').remove();

        // Change the "Salvar" button back to "Editar"
        box.find('.editar-btn').text('Editar');
      });

      // Salvar button click event
      $(document).on('click', '.salvar-btn', function() {
        var box = $(this).closest('.mensagem-historico-box');
        var mensagemId = box.attr('data-mensagem-id');
        var descricao = box.find('.message-enviar-field').val();
        var token = '<?php echo addslashes(json_encode($_SESSION['token'])); ?>';
        
        // Perform the AJAX request to update the message
        $.ajax({
          url: '../../back/curl/curl-updatemessage.php',
          method: 'POST',
          data: {
            mensagem_id: mensagemId,
            descricao: descricao,
            token: token
          },
          success: function(response) {
            // Handle the response from curl-updatemessage.php if needed
            console.log(response);
            // Reload the page to reflect the changes
            location.reload();
          },
          error: function(xhr, status, error) {
            console.error(error);
          }
        });
      });
    });
  </script>
</body>
</html>