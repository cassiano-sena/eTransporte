<?php
// error_reporting(E_ALL);
// ini_set('display_errors', 1);
require_once '../security/path.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap-grid.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>index.css">
    <link rel="stylesheet" href="<?php echo CSS ;?>comum.css">
    <script src="<?php echo JS ;?>bootstrap.min.js"></script>
    <title>eTransporte</title>
    <style>
        .mensagem-enviar-box{
            overflow:hidden;
        }
    </style>
</head>
<body>
<div class="conteudo">
    <div class="mensagem-enviar-box">
        <div class="mensagem-enviar-transporte">
            <div class="msg-enviar-transporte"  style="height:100%; width:100%;">Usuário<br>
                <img src="<?php echo IMAGES ;?>usuario.png" alt="usuário" width="50px" style="padding:10px; padding-left:4px;">
            </div>
        </div>
        <div class="mensagem-enviar-content">
            <div style="margin-top:10px;">
                <textarea id="descricao" name="descricao" rows="4" cols="50" class="mensagem-enviar-field" value="<?php $descricao ?>"></textarea>
            </div>
            <div style="text-align:left;line-height:1.5;height:50px;">
                <div style="display:flex;margin:10px;margin-right:20px;">
                    <select id="rota" name="rota" id="">
                        <option value=""></option>
                        <option value="<?php $rota ?>">Rota 1</option>
                    </select>
                    <div class="spacer"></div>
                    <button type="button" class="btn btn-primary btn-sm">Enviar</button>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>