<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Head content here -->
</head>
<body>
    <div class="conteudo">
        <div class="home-title">
            <div class="login-main">
                <!-- Rest of the HTML code -->

                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    document.getElementById('loginButton').addEventListener('click', function() {
                        var email = document.getElementById('email').value;
                        var senha = document.getElementById('senha').value;

                        var xhr = new XMLHttpRequest();
                        xhr.open('POST', 'login-ajax-file.php', true);
                        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                        xhr.onreadystatechange = function() {
                            if (xhr.readyState === XMLHttpRequest.DONE) {
                                if (xhr.status === 200) {
                                    // Handle successful response
                                    var response = xhr.responseText;
                                    // Redirect or perform further actions as needed
                                    if (response === 'success') {
                                        window.location.href = 'home.php';
                                    } else {
                                        // Handle authentication error
                                        console.error(response);
                                    }
                                } else {
                                    // Handle error response
                                    console.error(xhr.responseText);
                                }
                            }
                        };

                        var params = 'email=' + encodeURIComponent(email) + '&senha=' + encodeURIComponent(senha);
                        xhr.send(params);
                    });
                });
                </script>
            </div>
        </div>
    </div>
</body>
</html>
