<?php
// error_reporting(E_ALL);
// ini_set('display_errors', 1);
require_once '../security/path.php';
require_once CURL . 'curl-token.php';
require_once SECURITY . 'funcoes.php';

$email = $_POST['email'];
$senha = $_POST['senha'];

// Perform authentication using the provided email and password
// Assuming the authentication logic is implemented in the 'curl-token.php' file
// $authenticated = login($email, $senha);

// if ($authenticated) {
//     // Redirect to the home page if authentication is successful
//     echo 'success';
// } else {
//     // Handle authentication error
//     echo 'Incorrect email or password';
// }
?>
