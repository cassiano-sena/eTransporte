<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'security/path.php';
header("Location: ".PAGES."login.php");
?>